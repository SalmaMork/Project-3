# BustTheGhost
This is a boilerplate code for the Bust The Ghost Game
